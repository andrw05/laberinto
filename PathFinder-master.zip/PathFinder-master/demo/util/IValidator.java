package util;

public interface IValidator<V> {

	public boolean validates(V value);
}
